BEFORE_SCRIPT_DIR=$(dirname $0)

source $BEFORE_SCRIPT_DIR/common_env.sh
source $BEFORE_SCRIPT_DIR/travis_env.sh

source $BEFORE_SCRIPT_DIR/setup.sh

source $BEFORE_SCRIPT_DIR/start.sh
