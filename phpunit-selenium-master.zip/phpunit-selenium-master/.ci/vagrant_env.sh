#!/bin/bash

ESCAPED_BUILD_DIR="\/vagrant"
