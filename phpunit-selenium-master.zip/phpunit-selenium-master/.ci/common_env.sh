#!/bin/bash

SELENIUM_HUB_URL='http://127.0.0.1:4444'
SELENIUM_JAR=/usr/share/selenium/selenium-server-standalone.jar
SELENIUM_DOWNLOAD_URL=http://selenium-release.storage.googleapis.com/2.48/selenium-server-standalone-2.48.2.jar
PHP_VERSION=$(php -v)
