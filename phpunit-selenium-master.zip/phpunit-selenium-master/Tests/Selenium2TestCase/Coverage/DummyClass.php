<?php
class DummyClass
{
    public function coveredMethod()
    {
        return NULL;
    }

    public function uncoveredMethod()
    {
        return NULL;
    }
}
