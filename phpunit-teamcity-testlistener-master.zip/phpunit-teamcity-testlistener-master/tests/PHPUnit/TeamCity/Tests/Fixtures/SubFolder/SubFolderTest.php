<?php

namespace PHPUnit\TeamCity\Tests\Fixtures\SubFolder;

class SubFolderTest extends \PHPUnit_Framework_TestCase
{
    public function testSubMethod()
    {

    }
}
